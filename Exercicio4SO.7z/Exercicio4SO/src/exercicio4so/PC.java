package exercicio4so;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class PC implements Runnable {

    private ArrayList<Integer> lista;
    private Semaphore semaforo;

    public PC(ArrayList<Integer> lista, Semaphore semaforo) {
        this.lista = lista;
        this.semaforo = semaforo;
    }

    @Override
    public void run() {
        Random random = new Random();
        int numero;
        for (int x = 0; x < 5; x++) {
            numero = random.nextInt(90) + 10;

            try {
                semaforo.acquire();
                lista.add(numero);
            } catch (InterruptedException ex) {
                Logger.getLogger(PC.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                semaforo.release();
            }

            try {
                Thread.sleep(random.nextInt(1700) + 300);
            } catch (InterruptedException ex) {
                Logger.getLogger(PC.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(Thread.currentThread().getName() + " adicionou o valor " + numero);
        }
        System.out.println(Thread.currentThread().getName() + " terminou");
    }
}

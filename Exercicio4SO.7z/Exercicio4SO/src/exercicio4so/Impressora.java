package exercicio4so;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Impressora implements Runnable {

    private Semaphore semaforo;
    private ArrayList<Integer> lista;

    public Impressora(Semaphore semaforo, ArrayList<Integer> lista) {
        this.semaforo = semaforo;
        this.lista = lista;
    }

    @Override
    public void run() {
        int tempo = 0;

        for (int i = 0; i < 1000; i++) {

            try {
                semaforo.acquire();
                if (!lista.isEmpty()) {
                    tempo = lista.get(0);
                    lista.remove(0);
                    System.out.println("Removeu o valor: " + tempo);
                } else {
                    tempo = 2;
                    System.out.println("Vazio");
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Impressora.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                semaforo.release();
            }

            try {
                Thread.sleep(tempo);
            } catch (InterruptedException ex) {
                Logger.getLogger(Impressora.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}

package exercicio4so;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Impressora implements Runnable {

    
    private Semaphore semaforo;
    
    
    @Override
    public void run() {

        try {
            semaforo.acquire();
        } catch (InterruptedException ex) {
            Logger.getLogger(Impressora.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

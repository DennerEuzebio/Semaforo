package exercicio4so;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;

public class Exercicio4SO {

    public static void main(String[] args) {

        ArrayList<Integer> lista = new ArrayList<>();

        Semaphore semaforo = new Semaphore(1);
        //Crias os PCs (produtores)
        Thread[] PCs = new Thread[5];
        for (int i = 0; i < 5; i++) {
            PCs[i] = new Thread(new PC(lista, semaforo));
            PCs[i].setName("PC " + i);
            PCs[i].start();
        }

        try {
            for (int i = 0; i < 5; i++) {
                PCs[i].join();
            }
        } catch (InterruptedException e) {
        }

        System.out.println(lista);
    }

}
